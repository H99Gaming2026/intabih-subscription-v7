package com.intabih.subscription;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        String name = intent.getStringExtra("name");
        int days = intent.getIntExtra("days", 0);
        String msg = days == 0 ? "ينتهي اليوم. راجع التجديد أو ألغِه إذا لم تعد تريده."
            : days == 1 ? "ينتهي غدًا. راجع إعدادات التجديد."
            : "باقي 3 أيام على الانتهاء. لا تنسَ مراجعة التجديد.";
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(context, "subscription_reminders") : new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("تذكير باشتراكك: " + (name == null ? "" : name))
            .setContentText(msg).setAutoCancel(true);
        nm.notify((name == null ? 1 : name.hashCode()) + days, b.build());
    }
}
